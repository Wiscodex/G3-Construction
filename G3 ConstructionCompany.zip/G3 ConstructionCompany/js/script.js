let nav = document.getElementById('show-links').style.height;
let menu = document.getElementById('menu');

function toggle() {
    let nav = document.getElementById('show-links');
    let nav1 = document.getElementById('show-links').style.height;
    if (nav1 == '210px') {
        nav.style.height = '0px';
    }
    else {
        nav.style.height = '210px';
    }
}